import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { DragonBallService } from '../dragon-ball.service';

@Component({
  selector: 'app-characters',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './characters.component.html',
  styleUrls: ['./characters.component.css']
})
export class CharactersComponent implements OnInit {
  characters: any[] = [];
  searchForm: FormGroup;

  constructor(private fb: FormBuilder, private dragonBallService: DragonBallService) {
    this.searchForm = this.fb.group({
      query: ['']
    });
  }

  ngOnInit(): void {
    this.searchForm.get('query')?.valueChanges.subscribe(query => {
      if (query) {
        this.dragonBallService.getCharacters(query).subscribe(data => {
          this.characters = data;
        }, error => {
          console.error('Error loading characters:', error);
        });
      } else {
        this.characters = [];
      }
    });
  }
}