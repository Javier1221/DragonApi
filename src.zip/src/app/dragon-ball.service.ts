import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DragonBallService {
  private apiUrl = 'https://dragonball-api.com/api/characters'; // Reemplaza con la URL real de la API

  constructor(private http: HttpClient) { }

  getCharacters(query: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer YOUR_API_KEY` // Reemplaza con tu clave API si es necesario
    });
    return this.http.get<any>(`${this.apiUrl}?name=${query}`, { headers });
  }
}
